SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://AAncamilla:manchester12,@yury.mysql.database.azure.com:3306/correo_yury'
SQLALCHEMY_TRACK_MODIFICATIONS = False