
-- Insertar registros en la tabla Usuario
INSERT INTO Usuario (RUT, DV, username, password, role) VALUES 
(98765432, 'Z', 'AnaS', '202cb962ac59075b964b07152d234b70', 'Trabajador'),
(54321678, 'Q', 'trabajador3', '202cb962ac59075b964b07152d234b70', 'Trabajador'),
(13579246, 'P', 'jefeRRHH2', '202cb962ac59075b964b07152d234b70', 'JefeRRHH'),
(24681357, 'R', 'personalRRHHX', '202cb962ac59075b964b07152d234b70', 'PersonalRRHH'),
(65432109, 'S', 'trabajador4', '202cb962ac59075b964b07152d234b70', 'Trabajador'),
(98761234, 'T', 'trabajador5', '202cb962ac59075b964b07152d234b70', 'Trabajador'),
(11111111, 'U', 'jefeRRHH3', '202cb962ac59075b964b07152d234b70', 'JefeRRHH'),
(22222222, 'V', 'personalRRHH3', '202cb962ac59075b964b07152d234b70', 'PersonalRRHH'),
(33333333, 'W', 'trabajador6', '202cb962ac59075b964b07152d234b70', 'Trabajador'),
(44444444, 'X', 'trabajador7', '202cb962ac59075b964b07152d234b70', 'Trabajador'),
(55555555, 'Y', 'jefeRRHH4', '202cb962ac59075b964b07152d234b70', 'JefeRRHH'),
(66666666, 'Z', 'personalRRHH4', '202cb962ac59075b964b07152d234b70', 'PersonalRRHH');

-- Insertar registros en la tabla DatosPersonales
INSERT INTO DatosPersonales (nombre_completo, sexo, direccion, telefono, RUT) VALUES 
('Ana Sánchez', 'Femenino', 'Av. Independencia', '555444333', 98765432),
('Carlos González', 'Masculino', 'Calle del Sol', '333222111', 54321678),
('Lucía Rodríguez', 'Femenino', 'Av. Constitución', '111000999', 13579246),
('Mateo Ramírez', 'Masculino', 'Av. Colón', '444555666', 24681357),
('Sofía García', 'Femenino', 'Av. OHiggins', '777888999', 65432109),
('Diego Hernández', 'Masculino', 'Calle de la Luna', '111222333', 98761234),
('Laura Díaz', 'Femenino', 'Calle de las Flores', '444333222', 11111111),
('Andrés Silva', 'Masculino', 'Av. Los Ángeles', '999888777', 22222222),
('Javiera Muñoz', 'Femenino', 'Calle del Mar', '666777888', 33333333),
('Pedro Pérez', 'Masculino', 'Calle de las Palmeras', '333222111', 44444444),
('María Fernández', 'Femenino', 'Av. del Bosque', '555666777', 55555555),
('Lucas Morales', 'Masculino', 'Calle del Río', '888999000', 66666666);

-- Insertar registros en la tabla DatosLaborales
INSERT INTO DatosLaborales (cargo, fecha_ingreso, area, departamento, RUT) VALUES 
('Analista', '2020-01-01', 'IT', 'Desarrollo', 12345678),
('Jefe de Recursos Humanos', '2018-05-15', 'Recursos Humanos', 'Administración', 87654321),
('Asistente de Recursos Humanos', '2019-11-20', 'Recursos Humanos', 'Administración', 11223344),
('Desarrollador', '2017-08-10', 'IT', 'Desarrollo', 98765432),
('Diseñador Gráfico', '2019-02-28', 'Diseño', 'Marketing', 54321678),
('Analista Senior', '2016-03-05', 'IT', 'Desarrollo', 13579246),
('Coordinador de Personal', '2018-09-12', 'Recursos Humanos', 'Administración', 24681357),
('Programador', '2018-12-24', 'IT', 'Desarrollo', 65432109),
('Técnico de Soporte', '2020-06-30', 'IT', 'Soporte', 98761234),
('Contador', '2019-10-18', 'Finanzas', 'Administración', 11111111),
('Analista de Marketing', '2017-04-15', 'Marketing', 'Marketing', 22222222),
('Especialista en Comunicaciones', '2018-11-08', 'Comunicaciones', 'Marketing', 33333333),
('Asistente Administrativo', '2020-02-10', 'Administración', 'Administración', 44444444),
('Ingeniero de Software', '2016-07-01', 'IT', 'Desarrollo', 55555555),
('Gerente de Proyectos', '2015-09-20', 'Proyectos', 'Administración', 66666666);

-- Insertar registros en la tabla ContactoEmergencia
INSERT INTO ContactoEmergencia (nombre, relacion, telefono, RUT) VALUES 
('María López', 'Esposa', '987654321', 12345678),
('Joe Pérez', 'Padre', '954321', 87654321),
('Ana Martínez', 'Madre', '888777666', 11223344),
('Roberto Sánchez', 'Hermano', '666555444', 98765432),
('Lucía González', 'Hermana', '444333222', 54321678),
('Javier Rodríguez', 'Padre', '333222111', 13579246),
('Andrea Ramírez', 'Madre', '111000999', 24681357),
('Santiago García', 'Padre', '777888999', 65432109),
('Gabriela Hernández', 'Madre', '111222333', 98761234),
('Diego Díaz', 'Padre', '444555666', 11111111),
('Laura Silva', 'Madre', '999888777', 22222222),
('Andrés Muñoz', 'Padre', '666777888', 33333333),
('Pedro Pérez', 'Padre', '333222111', 44444444),
('María Fernández', 'Madre', '555666777', 55555555),
('Lucas Morales', 'Padre', '888999000', 66666666);

-- Insertar registros en la tabla CargasFamiliares
INSERT INTO CargasFamiliares (nombre, parentesco, sexo, rut_familiar, RUT) VALUES 
('Pedro Pérez Jr.', 'Hijo', 'Masculino', '236789-0', 12345678),
('Sofía Pérez', 'Hija', 'Femenino', '21000111-0', 12345678),
('Lucas Martínez', 'Hijo', 'Masculino', '34567890-1', 87654321),
('María Martínez', 'Hija', 'Femenino', '32109876-5', 87654321),
('Juan Sánchez', 'Hijo', 'Masculino', '45678901-2', 11223344),
('Ana Sánchez', 'Hija', 'Femenino', '43210987-6', 11223344),
('Carlos González Jr.', 'Hijo', 'Masculino', '56789012-3', 98765432),
('Lucía González', 'Hija', 'Femenino', '54321098-7', 98765432),
('Mateo Rodríguez', 'Hijo', 'Masculino', '67890123-4', 54321678),
('María Rodríguez', 'Hija', 'Femenino', '65432109-8', 54321678),
('Diego Ramírez', 'Hijo', 'Masculino', '78901234-5', 13579246),
('Laura Ramírez', 'Hija', 'Femenino', '76543210-9', 13579246),
('Andrea García', 'Hija', 'Femenino', '89012345-6', 24681357),
('Santiago García Jr.', 'Hijo', 'Masculino', '87654321-0', 24681357),
('Gabriela Hernández', 'Hija', 'Femenino', '90123456-7', 65432109);
